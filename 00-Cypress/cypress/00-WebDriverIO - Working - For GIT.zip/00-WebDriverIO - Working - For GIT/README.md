👋 End-to-End Automation Testing with WDIO and Cucumber
Multi-browser framework for End-to-End Automation Testing with WebdriverIO

✨ Pre-requisites:
NodeJs
Chrome browser 110

🔨 Running the project:
Clone the repo - main branch
CD into the WebDriverIO folder
Install dependencies running npm install
Run npm run wdio